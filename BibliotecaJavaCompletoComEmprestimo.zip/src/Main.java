package src;

import src.view.MainView;

public class Main {
    public static void main(String[] args) {
        new MainView();
    }
}
