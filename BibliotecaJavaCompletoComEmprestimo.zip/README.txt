Sistema de Biblioteca em Java com MySQL/MariaDB

Requisitos:
- Java JDK 8+
- MySQL ou MariaDB
- mysql-connector-java na pasta lib/

Como rodar:
1. Importe o script 'database/biblioteca.sql' no seu banco de dados MySQL.
2. Compile e execute o programa a partir da classe 'src.Main'.
